from flask import Flask, render_template, request, redirect, session, url_for, flash
from werkzeug.utils import secure_filename
import json
import os
import PyPDF2
import docx
from db import engine, SessionLocal, Base
from models import User, Report
from ai import analyze_resume

app = Flask(__name__)
app.secret_key = "a_very_secret_key_change_in_production"   # Change this!

# Allowed file extensions
ALLOWED_EXTENSIONS = {"pdf", "docx", "txt"}

def allowed_file(filename):
    return "." in filename and filename.rsplit(".", 1)[1].lower() in ALLOWED_EXTENSIONS

# Create tables (if not exist)
Base.metadata.create_all(bind=engine)

# -------------------- Routes --------------------

@app.route("/")
def home():
    if "user" in session:
        return redirect("/dashboard")
    return redirect("/login")

@app.route("/signup", methods=["GET", "POST"])
def signup():
    if request.method == "POST":
        email = request.form.get("email").strip()
        password = request.form.get("password").strip()
        if not email or not password:
            flash("Email and password required.")
            return render_template("signup.html")
        
        db = SessionLocal()
        # Check if user already exists
        existing = db.query(User).filter_by(email=email).first()
        if existing:
            db.close()
            flash("Email already registered. Please login.")
            return redirect("/login")
        
        # In a real app, hash the password (e.g., bcrypt)
        new_user = User(email=email, password=password)
        db.add(new_user)
        db.commit()
        db.close()
        flash("Account created! Please login.")
        return redirect("/login")
    return render_template("signup.html")

@app.route("/login", methods=["GET", "POST"])
def login():
    if request.method == "POST":
        email = request.form.get("email").strip()
        password = request.form.get("password").strip()
        db = SessionLocal()
        user = db.query(User).filter_by(email=email, password=password).first()
        db.close()
        if user:
            session["user"] = user.email
            session["user_id"] = user.id
            flash("Login successful!")
            return redirect("/dashboard")
        else:
            flash("Invalid credentials.")
    return render_template("login.html")

@app.route("/logout")
def logout():
    session.clear()
    flash("Logged out.")
    return redirect("/login")

@app.route("/dashboard", methods=["GET", "POST"])
def dashboard():
    if "user" not in session:
        return redirect("/login")
    
    result = None
    resume_text = ""
    target_role = ""

    if request.method == "POST":
        target_role = request.form.get("role", "").strip()
        resume_text = request.form.get("resume", "").strip()
        file = request.files.get("file")

        # If a file is uploaded, extract text
        if file and file.filename != "":
            if not allowed_file(file.filename):
                flash("Unsupported file format. Use PDF, DOCX, or TXT.")
                return render_template("dashboard.html", result=result)
            
            filename = secure_filename(file.filename)
            if filename.endswith(".pdf"):
                try:
                    reader = PyPDF2.PdfReader(file)
                    resume_text = "\n".join([page.extract_text() for page in reader.pages])
                except Exception as e:
                    flash(f"Error reading PDF: {e}")
                    return render_template("dashboard.html", result=result)
            elif filename.endswith(".docx"):
                try:
                    doc = docx.Document(file)
                    resume_text = "\n".join([para.text for para in doc.paragraphs])
                except Exception as e:
                    flash(f"Error reading DOCX: {e}")
                    return render_template("dashboard.html", result=result)
            else:  # .txt
                resume_text = file.read().decode("utf-8")

        # Ensure we have text and a role
        if not resume_text:
            flash("Please provide resume text or upload a file.")
            return render_template("dashboard.html", result=result)
        if not target_role:
            flash("Please specify a target job role.")
            return render_template("dashboard.html", result=result)

        # Call AI
        try:
            result = analyze_resume(resume_text, target_role)
        except Exception as e:
            flash(f"AI analysis failed: {e}")
            return render_template("dashboard.html", result=result)

        # Save report to database
        db = SessionLocal()
        user = db.query(User).filter_by(email=session["user"]).first()
        if user:
            new_report = Report(
                user_id=user.id,
                target_role=target_role,
                resume_text=resume_text,
                result=json.dumps(result)
            )
            db.add(new_report)
            db.commit()
        db.close()

    return render_template("dashboard.html", user=session["user"], result=result)

@app.route("/history")
def history():
    if "user" not in session:
        return redirect("/login")
    
    db = SessionLocal()
    user = db.query(User).filter_by(email=session["user"]).first()
    reports = []
    if user:
        reports = db.query(Report).filter_by(user_id=user.id).order_by(Report.id.desc()).all()
    db.close()
    return render_template("history.html", reports=reports)

# -------------------- Run --------------------
if __name__ == "__main__":
    app.run(debug=True)