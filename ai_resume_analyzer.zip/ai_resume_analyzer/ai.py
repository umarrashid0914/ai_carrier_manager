import openai
import json

client = openai.OpenAI(base_url="http://localhost:11434/v1", api_key="ollama")   # Replace with your key

def analyze_resume(resume_text, target_role):
    """
    Send resume and role to GPT-4o-mini and return structured JSON.
    """
    prompt = f"""
You are a Senior Hiring Manager and Career Coach.
Evaluate the resume for the target role: {target_role}.

Resume Content:
{resume_text}

Return a valid JSON object with the following fields:
- "skills": list of skills found in the resume
- "missing_skills": list of important skills missing for the target role
- "road_map": a step‑by‑step learning roadmap (text)
- "interview_questions": list of 5 interview questions for this role

Return ONLY the JSON, no extra text.
"""
    try:
        response = client.chat.completions.create(
            model="mistral:latest",
            messages=[{"role": "user", "content": prompt}],
            temperature=0.3,
            max_tokens=1000
        )
        content = response.choices[0].message.content.strip()
        # Clean possible markdown code fences
        if content.startswith("```json"):
            content = content[7:]
        if content.endswith("```"):
            content = content[:-3]
        return json.loads(content)
    except Exception as e:
        # Fallback in case of AI error
        return {
            "skills": [],
            "missing_skills": [],
            "road_map": f"Error analysing resume: {str(e)}",
            "interview_questions": []
        }